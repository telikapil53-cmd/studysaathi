# StudySaathi PWA (GitHub Pages)

## Included
- index.html — StudySaathi website
- manifest.json — install metadata
- service-worker.js — app-shell caching
- icon.svg, icon-192.png, icon-512.png — app icons

## Publish for free
1. Sign in to https://github.com/ and create a **Public** repository named `studysaathi`.
2. Upload all six files from this folder into the repository root (not inside another nested folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then save.
6. Wait for GitHub Pages to publish the site. Open the HTTPS URL it shows.
7. On Android, open that URL in Chrome, tap ⋮, then choose **Install app** or **Add to Home screen**.

## Important
- The site must be served over HTTPS for service workers and PWA install behavior.
- The AI Tutor currently remains a local demo; no real AI API/backend is connected.
- GitHub Pages is static hosting and cannot securely store secret API keys or run a private AI backend.
- Study plans, notes and progress are stored in the browser on that device. Keep a backup if the data matters.
- PWA installation is free. Publishing a separate Android APK or listing the app on Google Play is a different process and may have separate requirements/fees.
